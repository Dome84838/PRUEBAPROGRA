public class Delegacion {
    private String Pais;
    private int nroDeportistas;
    private int medallasOro;
    private int medallasPlata;
    private int medallasBronce;


    public String getPais() {
        return Pais;
    }

    public void setPais(String pais) {
        Pais = pais;
    }

    public int getNroDeportistas() {
        return nroDeportistas;
    }

    public void setNroDeportistas(int nroDeportistas) {
        this.nroDeportistas = nroDeportistas;
    }

    public int getMedallasOro() {
        return medallasOro;
    }

    public void setMedallasOro(int medallasOro) {
        this.medallasOro = medallasOro;
    }

    public int getMedallasPlata() {
        return medallasPlata;
    }

    public void setMedallasPlata(int medallasPlata) {
        this.medallasPlata = medallasPlata;
    }

    public int getMedallasBronce() {
        return medallasBronce;
    }

    public void setMedallasBronce(int medallasBronce) {
        this.medallasBronce = medallasBronce;
    }



}
