import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
      Delegacion d1, d2, d3;
        Scanner sc = new Scanner(System.in);
        String pais;
        int nroDeportistas, medallasOro,medallasPlata,medallasBronce;

      public pais {
        System.out.println("Ingrese los Datos para sus delegaciones:");
        System.out.println("Ingrese el nmbre del pais");
        pais = sc.next();
      }
      public nroDeportistas {
        System.out.println("Ingrese el numero de Deportistas");
        nroDeportistas = sc.nextInt();
      }
      public medallasOro {
        System.out.println("Ingrese el numero de medallas de oro");
        medallasOro = sc.nextInt();
      }
      public  medallasPlata {
        System.out.println("Ingrese el numero de medallas de plata");
        medallasPlata = sc.nextInt();
      }

      public   medallasBronce{
       System.out.println("Ingrese el numero de medallas de bronce");
        medallasBronce = sc.nextInt();

        d1= new Delegacion(pais,nroDeportistas,medallasOro,medallasPlata,medallasBronce);

        System.out.println("Ingrese los Datos para sus delegaciones:");
         public pais {
          System.out.println("Ingrese los Datos para sus delegaciones:");
          System.out.println("Ingrese el nmbre del pais");
          d2 pais = sc.next();
        }
      public nroDeportistas {
          System.out.println("Ingrese el numero de Deportistas");
          d2 nroDeportistas = sc.nextInt();
        }
      public medallasOro {
          System.out.println("Ingrese el numero de medallas de oro");
          d2 medallasOro = sc.nextInt();
        }
      public  medallasPlata {
          System.out.println("Ingrese el numero de medallas de plata");
         d2 medallasPlata = sc.nextInt();
        }

      public   medallasBronce{
          System.out.println("Ingrese el numero de medallas de bronce");
          d2 medallasBronce = sc.nextInt();

          d2= new Delegacion(pais,nroDeportistas,medallasOro,medallasPlata,medallasBronce);


         public pais {
            System.out.println("Ingrese los Datos para sus delegaciones:");
            System.out.println("Ingrese el nmbre del pais");
            d3 pais = sc.next();
          }
      public nroDeportistas {
            System.out.println("Ingrese el numero de Deportistas");
            d3 nroDeportistas = sc.nextInt();
          }
      public medallasOro {
            System.out.println("Ingrese el numero de medallas de oro");
            d3 medallasOro = sc.nextInt();
          }
      public  medallasPlata {
            System.out.println("Ingrese el numero de medallas de plata");
            d3 medallasPlata = sc.nextInt();
          }

      public   medallasBronce{
            System.out.println("Ingrese el numero de medallas de bronce");
            d3 medallasBronce = sc.nextInt();
        d3= new Delegacion(pais,nroDeportistas,medallasOro,medallasPlata,medallasBronce);

      }

      System.out.println("----------MENU----------");


    }


}